package com.zorba.bt.app.bluetooth;

public class NetworkInfo {

	public String ssid = "";
	public String subnet = "";
	public int unusedIndex = -1;
}
