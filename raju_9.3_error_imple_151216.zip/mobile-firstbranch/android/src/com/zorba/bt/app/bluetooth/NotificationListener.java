package com.zorba.bt.app.bluetooth;

public interface NotificationListener {
   void notificationReceived(byte[] var1);
}
