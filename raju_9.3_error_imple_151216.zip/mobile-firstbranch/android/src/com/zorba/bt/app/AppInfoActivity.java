package com.zorba.bt.app;

import android.os.Bundle;

public class AppInfoActivity extends ZorbaActivity {
   protected void onCreate(Bundle var1) {
      super.onCreate(var1);
      this.setContentView(R.layout.about);
   }
}
